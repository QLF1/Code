#ifndef __DELAY_H__
#define __DELAY_H__

void TIM2Init(void);
void delay_ms(int tim);

#endif
