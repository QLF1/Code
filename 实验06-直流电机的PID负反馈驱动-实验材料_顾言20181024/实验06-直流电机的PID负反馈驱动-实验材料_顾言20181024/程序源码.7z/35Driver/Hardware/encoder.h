#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
short Encoder_read(void);
	
#endif

