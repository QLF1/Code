#ifndef __DELAY_H__
#define __DELAY_H__

void TIM7_Configration(void);
void TIM6_Configration(void);
void delay_ms(int tim);
void delay_us(int tim);

#endif 

